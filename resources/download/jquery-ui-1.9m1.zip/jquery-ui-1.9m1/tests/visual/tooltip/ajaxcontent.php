<?php sleep(1); ?>
<strong>Hello</strong> world!