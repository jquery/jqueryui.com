/*
 * button_tickets.js
 */
(function($) {

module("button: tickets");



})(jQuery);
