/*
 * droppable_tickets.js
 */
(function($) {

module("droppable: tickets");

})(jQuery);
