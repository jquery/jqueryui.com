/*
 * autocomplete_tickets.js
 */
(function($) {

module("autocomplete: tickets", {
	teardown: function() {
		$( ":ui-autocomplete" ).autocomplete( "destroy" );
	}
});



})(jQuery);
