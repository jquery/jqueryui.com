(function( $ ) {

module( "accordion: tickets", accordionSetupTeardown() );

}( jQuery ) );
