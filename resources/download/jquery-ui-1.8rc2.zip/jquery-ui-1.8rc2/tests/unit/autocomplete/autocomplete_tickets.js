/*
 * autocomplete_tickets.js
 */
(function($) {

module("autocomplete: tickets");



})(jQuery);
