/*
 * datepicker_defaults.js
 */

var datepicker_defaults = {
	disabled: false
};

//TestHelpers.commonWidgetTests('datepicker', { defaults: datepicker_defaults });
