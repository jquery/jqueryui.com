/*
 * menu_defaults.js
 */

var menu_defaults = {
	disabled: false,
	navigationFilter: function() {}
	
};

commonWidgetTests('menu', { defaults: menu_defaults });
