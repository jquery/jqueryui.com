/*
 * jQuery UI Effects Fold 1.6rc5
 *
 * Copyright (c) 2009 AUTHORS.txt (http://ui.jquery.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI/Effects/Fold
 *
 * Depends:
 *	effects.core.js
 */eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('(q(a){a.5.Q=q(b){L w.M(q(){3 e=a(w),k=["V","X","W"];3 h=a.5.K(e,b.7.U||"p");3 o=b.7.Y||R;3 n=!(!b.7.F);3 g=b.s?b.s/2:a.y.J.H/2;a.5.T(e,k);e.8();3 d=a.5.C(e).v({B:"D"});3 i=((h=="8")!=n);3 f=i?["6","4"]:["4","6"];3 c=i?[d.6(),d.4()]:[d.4(),d.6()];3 j=/([0-9]+)%/.G(o);r(j){o=E(j[1])/I*c[h=="p"?0:1]}r(h=="8"){d.v(n?{4:0,6:o}:{4:o,6:0})}3 m={},l={};m[f[0]]=h=="8"?c[0]:o;l[f[1]]=h=="8"?c[1]:0;d.u(m,g,b.7.t).u(l,g,b.7.t,q(){r(h=="p"){e.p()}a.5.S(e,k);a.5.O(e);r(b.x){b.x.P(e[0],N)}e.z()})})}})(A);',61,61,'|||var|height|effects|width|options|show|||||||||||||||||hide|function|if|duration|easing|animate|css|this|callback|fx|dequeue|jQuery|overflow|createWrapper|hidden|parseInt|horizFirst|exec|_default|100|speeds|setMode|return|queue|arguments|removeWrapper|apply|fold|15|restore|save|mode|position|left|top|size'.split('|'),0,{}))
