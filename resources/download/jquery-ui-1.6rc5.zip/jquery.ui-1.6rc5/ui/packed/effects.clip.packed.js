/*
 * jQuery UI Effects Clip 1.6rc5
 *
 * Copyright (c) 2009 AUTHORS.txt (http://ui.jquery.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI/Effects/Clip
 *
 * Depends:
 *	effects.core.js
 */eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('(6(a){a.3.C=6(b){D w.t(6(){1 f=a(w),j=["7","u","v","9","l"];1 i=a.3.I(f,b.o.N||"8");1 k=b.o.H||"4";a.3.P(f,j);f.5();1 c=a.3.E(f).m({Q:"y"});1 e=f[0].A=="K"?c:f;1 g={n:(k=="4")?"9":"l",7:(k=="4")?"u":"v"};1 d=(k=="4")?e.9():e.l();p(i=="5"){e.m(g.n,0);e.m(g.7,d/2)}1 h={};h[g.n]=i=="5"?d:0;h[g.7]=i=="5"?0:d/2;e.O(h,{t:L,r:b.r,q:b.o.q,G:6(){p(i=="8"){f.8()}a.3.J(f,j);a.3.F(f);p(b.s){b.s.x(f[0],z)}f.B()}})})}})(M);',53,53,'|var||effects|vertical|show|function|position|hide|height||||||||||||width|css|size|options|if|easing|duration|callback|queue|top|left|this|apply|hidden|arguments|tagName|dequeue|clip|return|createWrapper|removeWrapper|complete|direction|setMode|restore|IMG|false|jQuery|mode|animate|save|overflow'.split('|'),0,{}))
