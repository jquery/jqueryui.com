/*
 * jQuery UI Effects Slide 1.6rc4
 *
 * Copyright (c) 2008 AUTHORS.txt (http://ui.jquery.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI/Effects/Slide
 *
 * Depends:
 *	effects.core.js
 */eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('(2(A){A.1.y=2(B){w 7.b(2(){0 E=A(7),D=["t","8","5"];0 I=A.1.P(E,B.3.N||"4");0 H=B.3.M||"5";A.1.n(E,D);E.4();A.1.k(E).d({j:"O"});0 F=(H=="h"||H=="o")?"8":"5";0 C=(H=="h"||H=="5")?"6":"p";0 J=B.3.q||(F=="8"?E.m({e:c}):E.l({e:c}));9(I=="4"){E.d(F,C=="6"?-J:J)}0 G={};G[F]=(I=="4"?(C=="6"?"+=":"-="):(C=="6"?"-=":"+="))+J;E.s(G,{b:K,a:B.a,f:B.3.f,z:2(){9(I=="g"){E.g()}A.1.v(E,D);A.1.x(E);9(B.i){B.i.u(7,Q)}E.r()}})})}})(L)',53,53,'var|effects|function|options|show|left|pos|this|top|if|duration|queue|true|css|margin|easing|hide|up|callback|overflow|createWrapper|outerWidth|outerHeight|save|down|neg|distance|dequeue|animate|position|apply|restore|return|removeWrapper|slide|complete|||||||||||false|jQuery|direction|mode|hidden|setMode|arguments'.split('|'),0,{}))
