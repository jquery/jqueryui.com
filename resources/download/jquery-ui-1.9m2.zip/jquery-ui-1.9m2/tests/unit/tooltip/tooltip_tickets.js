/*
 * tooltip_tickets.js
 */
(function($) {

module("tooltip: tickets");



})(jQuery);
