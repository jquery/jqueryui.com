/*
 * button_events.js
 */
(function() {

module("button: events");

})(jQuery);
