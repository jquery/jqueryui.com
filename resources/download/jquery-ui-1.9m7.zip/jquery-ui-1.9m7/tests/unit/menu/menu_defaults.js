commonWidgetTests( "menu", {
	defaults: {
		disabled: false,
		menus: "ul",
		position: {
			my: "left top",
			at: "right top"
		},

		// callbacks
		blur: null,
		create: null,
		focus: null,
		select: null
	}
});
