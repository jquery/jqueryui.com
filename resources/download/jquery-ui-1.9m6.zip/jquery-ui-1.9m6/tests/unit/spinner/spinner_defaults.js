commonWidgetTests( "spinner", {
	defaults: {
		disabled: false,
		incremental: true,
		max: null,
		min: null,
		numberFormat: null,
		page: 10,
		step: 1,

		// callbacks
		change: null,
		create: null,
		spin: null,
		start: null,
		stop: null
	}
});
