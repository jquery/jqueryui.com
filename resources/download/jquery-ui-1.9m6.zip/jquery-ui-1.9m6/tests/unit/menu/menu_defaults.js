commonWidgetTests( "menu", {
	defaults: {
		disabled: false,
		position: {
			my: "left top",
			at: "right top"
		},

		// callbacks
		create: null
	}
});
